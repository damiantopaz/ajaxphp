
export const HTTPURL = "192.168.1.4/ticketapp/api/";
export const FILEURL = "192.168.1.4/ticketapp/public/";