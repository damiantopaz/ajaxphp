<?php
  $db_server = 'localhost';
  $db_user = 'root';//'ici_ticketapp';
  $db_password = '';//'xSM73KIFbQg8';
  $db = 'ticketapp';//'ici_ticketapp';

  define('TICKET_PREFIX','TKT');


  define('ADMINPERMISSIONS',[
    'ADDADMIN',
    'LISTADMIN',
    'UPDATEADMIN',
    'VIEWADMIN',
    'UPDATEADMINPERMISSIONS',
    'CREATETICKET',
    'LISTTICKET',
    'MODIFYTICKET',
    'VIEWTICKET',
    'REPLYTICKET',
    'CREATECLIENT',
    'LISTCLIENT',
    'SEARCHCLIENT',
    'VIEWCLIENT',
    'UPDATECLIENT',
    'ADDDEPLOYMENT',
    'VIEWDEPLOYMENT',
    'VIEWDEPLOYMENTCOST',
    'VIEWDEPLOYMENTTIME',
    'UPDATEDEPLOYMENT',
    'UPDATEDEPLOYMENTFILE',
    'VIEWDEPLOYMENTFILE',
    'ADDPRODUCT',
    'LISTPRODUCT',
    'SEARCHPRODUCT',
    'DELETEPRODUCT',
    'UPDATEPRODUCT',
    'VIEWPRODUCT',
    'CREATEUSER',
    'LISTUSER',
    'VIEWUSER'
  ]);

  define('USERPERMISSIONS',[
    'CREATETICKET',
    'LISTTICKET',
    'MODIFYTICKET',
    'VIEWTICKET',
    'REPLYTICKET',
    'VIEWDEPLOYMENT',
    'VIEWDEPLOYMENTCOST',
  ]);
?>